﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace MovieGalleryAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {

        private readonly ApplicationDbContext _dbContext;

        public MoviesController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet("popular")]
        [Authorize]
        public IActionResult GetPopularMovies()
        {
            var popularMovies = _dbContext.Movies.ToList();
            return Ok(popularMovies);
        }

        [HttpGet("search")]
        [Authorize]
        public IActionResult SearchMovies(string keywords)
        {
            var matchedMovies = _dbContext.Movies
                .AsEnumerable()
                .Where(movie => movie.Title.Contains(keywords, StringComparison.OrdinalIgnoreCase))
                .ToList();
            return Ok(matchedMovies);
        }

        [HttpGet("{id}")]
        [Authorize]
        public IActionResult GetMovieDetails(int id)
        {
            var movie = _dbContext.Movies.FirstOrDefault(m => m.Id == id);
            if (movie == null)
                return NotFound();

            return Ok(movie);
        }

        [HttpPost("favorites/add")]
        [Authorize]
        public IActionResult AddToFavoriteList(int movieId)
        {
            var userId = int.Parse(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value);
            var existingFavorite = _dbContext.favorites.FirstOrDefault(fm => fm.UserId == userId && fm.MovieId == movieId);
            if (existingFavorite != null)
            {
                return BadRequest("The movie is already in the user's favorite list.");
            }

            var favoriteMovie = new FavoriteList { UserId = userId, MovieId = movieId };
            _dbContext.favorites.Add(favoriteMovie);
            _dbContext.SaveChanges();

            return Ok("Successfully add!");
        }

        [HttpPost("favorites/remove")]
        [Authorize]
        public IActionResult RemoveFromFavoriteList(int movieId)
        {
            var userId = int.Parse(User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value);

            var favoriteMovie = _dbContext.favorites.FirstOrDefault(fm => fm.UserId == userId && fm.MovieId == movieId);
            if (favoriteMovie == null)
            {
                return NotFound();
            }

            _dbContext.favorites.Remove(favoriteMovie);
            _dbContext.SaveChanges();

            return Ok("Favorite movie successfully remove!");
        }
    }
}
