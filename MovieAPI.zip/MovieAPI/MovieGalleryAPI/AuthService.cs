﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace MovieGalleryAPI
{
    public interface IAuthService
    {
        Users Authenticate(string username, string password);
    }
    public class AuthService : IAuthService
    {
        private readonly ApplicationDbContext _dbContext;

        public AuthService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public Users Authenticate(string username, string password)
        {
            var user = _dbContext.Users.FirstOrDefault(u => u.Username == username);
            if (user == null )
            {
                return null;
            }
            return user;
        }

    }
}
