﻿namespace MovieGalleryAPI
{
    public class FavoriteList
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int MovieId { get; set; }

    }
}
